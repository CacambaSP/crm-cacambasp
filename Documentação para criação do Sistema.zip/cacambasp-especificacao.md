# CaçambaSP — Especificação Técnica Completa
**Sistema de Gestão de Locação de Caçambas**
Versão 3.0.5 | Maio de 2026

---

## 1. Visão Geral do Negócio

### 1.1 Objetivo do Sistema
O CaçambaSP é um sistema de gestão completo para empresas de locação de caçambas de entulho. Gerencia todo o ciclo de vida de uma OS, desde o primeiro contato com o cliente até o pagamento de comissões para a equipe de vendas.

Desenvolvido como SPA (Single Page Application) usando HTML, CSS e JavaScript puro, sem frameworks, conectado ao Supabase (PostgreSQL).

### 1.2 Usuários do Sistema

| Perfil | Acesso | Descrição |
|---|---|---|
| Admin (Douglas) | Total | Todos os módulos, relatórios e configurações |
| Operador/Vendedor | Parcial | Apenas suas ordens, pode cadastrar e cobrar |
| Cliente | Tracking | Link de rastreamento via WhatsApp |
| Fornecedor | Externo | Recebe link de OS via WhatsApp |

### 1.3 Fluxo Principal de uma Ordem
1. **Contratar** → OS criada, vendedor informa valor
2. **Ag. Entrega** → Fornecedor atribuído, entrega agendada
3. **Entrega** → Caçamba entregue, aguardando retirada
4. **Receber (Pagar)** → Aguardando pagamento do cliente
5. **Falta Pagar** → Fornecedor pago, falta cliente pagar
6. **Baixar** → Cliente pagou, falta pagar fornecedor
7. **Inadimplente** → Cliente não pagou
8. **Concluído** → Arquivada, sai do Kanban

---

## 2. Arquitetura Técnica

### 2.1 Stack Tecnológico

| Componente | Tecnologia | Detalhes |
|---|---|---|
| Frontend Desktop | HTML/CSS/JS puro | index.html — SPA |
| Frontend Mobile | HTML/CSS/JS puro | mobile2.html — PWA |
| Tracking Cliente | HTML/CSS/JS puro | tracking.html — público |
| Banco de Dados | Supabase (PostgreSQL) | ejfuqijtiberxsnvxdwm.supabase.co |
| Hospedagem | Vercel | cacambasp-crm.vercel.app |
| Repositório | GitHub | CacambaSP/crm-cacambasp |
| Push Notifications | OneSignal | App ID: c2dbdd20-6f19-433f-8106-f45d3e37714d |
| Autenticação | Supabase Auth | JWT — email e senha |

### 2.2 Deploy e CI/CD
- Sobe arquivo no GitHub → Vercel detecta automaticamente → Deploy em ~8 segundos
- Sem processo de build — HTML estático servido diretamente
- URL: cacambasp-crm.vercel.app

### 2.3 Autenticação
- Supabase Auth com JWT
- Token armazenado no localStorage como `csm_session`
- Perfis na tabela `perfis` vinculados ao `auth.users` pelo campo `id`
- Campo `nivel`: `admin` ou `operador`

### 2.4 PWA — App Mobile
- PWA instalável, manifesto com ícone e nome "CRM Mobile2"
- Service Worker (sw.js) para cache e push notifications
- Badge nativo via `navigator.setAppBadge()`
- Notificações push via OneSignal
- Auto-refresh a cada 15 segundos

---

## 3. Banco de Dados

### 3.1 Tabela: ordens

| Campo | Tipo | Descrição |
|---|---|---|
| id | uuid PK | Identificador único |
| crm_id | text | Código ex: LC20266001 |
| col | text | Coluna: contratar/ag_entrega/entrega/pagar/faltapg/baixar/inadimp/concluido/orcamento |
| usuario_id | uuid FK | Vendedor responsável |
| nome | text | Nome do cliente |
| cel | text | Celular (só números) |
| cpf | text | CPF ou CNPJ |
| logradouro | text | Endereço de entrega |
| bairro | text | Bairro |
| cidade | text | Cidade (padrão: São Paulo) |
| cep | text | CEP |
| data | date | Data de entrega |
| tipo | text | Tipo de serviço |
| rec | numeric | Receita cobrada do cliente |
| cst | numeric | Custo do fornecedor |
| forn_id | uuid FK | Fornecedor atribuído |
| forn_pago | boolean | Fornecedor pago? |
| pago | boolean | Cliente pagou? |
| pago_em | timestamptz | Data do pagamento |
| pago_valor | numeric | Valor pago |
| cobrado_em | timestamptz | Última cobrança via WA |
| tracking_token | uuid | Token único para rastreamento |
| nf_num | text | Número da nota fiscal |
| nf_taxa | numeric | Taxa NF em % (padrão: 11%) |
| obs | text | Observações internas |
| cancel_motivo | text | Motivo do cancelamento |
| concluido_em | timestamptz | Data de arquivamento |
| entrega_confirmada | boolean | Entrega confirmada? |
| comissao_liberada | boolean | Comissão liberada manualmente? |
| criado_em | timestamptz | Data de criação |
| qtd | integer | Quantidade de caçambas |

### 3.2 Tabela: fornecedores

| Campo | Tipo | Descrição |
|---|---|---|
| id | uuid PK | Identificador único |
| nome | text | Nome do fornecedor |
| tel | text | Telefone |
| wa_link | text | Link do WhatsApp |
| regioes | jsonb | Array com bairro, turno e preço |
| ativo | boolean | Fornecedor ativo? |

### 3.3 Tabela: perfis

| Campo | Tipo | Descrição |
|---|---|---|
| id | uuid PK | Mesmo ID do auth.users |
| nome | text | Nome do usuário |
| email | text | Email |
| nivel | text | admin ou operador |
| marca_nome | text | Nome da marca (tracking) |
| marca_cor | text | Cor hex |
| marca_logo_url | text | URL do logo |
| marca_slogan | text | Slogan |
| marca_tel | text | Telefone de contato |

### 3.4 Tabela: comissoes_fechamento

| Campo | Tipo | Descrição |
|---|---|---|
| id | uuid PK | Identificador único |
| mes | date | Primeiro dia do mês (ex: 2026-04-01) |
| usuario_id | uuid FK | Vendedor |
| total_ordens | integer | Quantidade de ordens |
| valor_bruto | numeric | Receita total |
| valor_vendedor | numeric | Valor a pagar ao vendedor |
| valor_douglas | numeric | Parte do Douglas |
| valor_anuncio | numeric | Desconto de anúncio |
| fixo_garantido | numeric | Valor fixo garantido |
| status | text | pago ou pendente |
| pago_em | timestamptz | Data do pagamento |

### 3.5 Tabela: logs_ordens

| Campo | Tipo | Descrição |
|---|---|---|
| id | uuid PK | Identificador único |
| ordem_id | uuid FK | OS relacionada |
| acao | text | Ação: Criado, Pago, Cancelado, etc |
| detalhe | text | Detalhes da ação |
| usuario_id | uuid | Quem fez |
| criado_em | timestamptz | Data |

---

## 4. Módulos do Desktop (index.html)

### 4.1 Kanban (Funil)

**Colunas:**

| Coluna | Código | Significado |
|---|---|---|
| Contratar | contratar | Aguardando fornecedor |
| Ag. Entrega | ag_entrega | Entrega agendada |
| Entrega | entrega | Caçamba entregue |
| Receber | pagar | Aguardando cliente pagar |
| Falta Pagar | faltapg | Falta cliente pagar |
| Baixar | baixar | Falta pagar fornecedor |
| Inadimplente | inadimp | Cliente inadimplente |
| Orçamentos | orcamento | Proposta não confirmada |

**Funcionalidades:** drag & drop, busca em tempo real, filtro por vendedor, mini KPIs por coluna, duplicar ordem (sempre gera novo tracking_token), alertas de IA, cobrança via WA.

### 4.2 Dashboard
- KPIs: Ordens no mês (clicável), Receita bruta, Custo total, Margem líquida, Inadimplência
- Card "Ordens no mês" abre modal com status de Cliente / Fornecedor / Comissão por OS
- Top bairros, Top fornecedores, Top vendedores
- Resumo de fechamento de comissões

### 4.3 Comissões

**Modelos de comissão:**

| Vendedor | Fórmula |
|---|---|
| Luciana | 100% do lucro líquido |
| Letícia | 100% do lucro líquido |
| Cláudia | R$1.000 fixo + 50% restante (após fixo+anúncio) + 30% da Sandra |
| Sandra | R$300 fixo + 40% restante. 30% → Cláudia, 30% → Douglas |
| Ricardo | R$15 por ordem paga |
| Douglas | R$10 × todas ordens + 50% Cláudia + 30% Sandra + 60% LL próprio |

**Ordem de fechamento (CRÍTICO):**
1º Sandra → 2º Letícia/Luciana/Ricardo → 3º Cláudia → 4º Douglas

**Lucro Líquido:** `LL = Receita - Custo - Taxa Adm (R$10) - Imposto NF`

**Funcionalidades:** marcar/desmarcar ordens individualmente, totais em tempo real, ordens arquivadas+pagas incluídas (🏆), botão desfazer fechamento (🔓), aviso de ordem.

### 4.4 Conciliação Bancária
- Upload de extrato CSV/OFX
- Reconhece PIX com txid contendo crm_id, prefixo RC e GRP
- Marca ordens como pagas automaticamente

### 4.5 Notas Fiscais
- Preenchimento automático com dados da OS
- Acréscimo NF sobre valor da OS
- Regras: Osasco (ISS via PGDAS), São Paulo PJ (retenção na fonte)

### 4.6 Outros Módulos
- **Pagar Fornecedor:** lista e registra pagamentos por CNPJ
- **Cobrança Automática:** envia WA com link de rastreamento para ordens vencidas
- **Histórico:** linha do tempo de ações por OS
- **Alertas:** críticos, atenção e inadimplentes
- **Relatórios:** por período e vendedor
- **Cadastros:** fornecedores, clientes, usuários, configurações

---

## 5. Módulo Mobile (mobile2.html)

### 5.1 Grupos de Ação

| Grupo | Quem vê | O que mostra |
|---|---|---|
| Orçamentos | Todos | Orçamentos pendentes |
| Contratar | Admin: sem fornecedor / Vendedor: ordens dele | Ordens sem fornecedor |
| Aguardando entrega | Todos | Entrega agendada |
| Cobrar cliente | Todos | Não pagas há 3+ dias |
| Pagar fornecedor | Admin | Pagamentos pendentes |

### 5.2 Alerta de Valor
- Badge piscando no grupo com número de ordens sem valor
- Alerta laranja piscando no card
- Botão "+ Valor" → prompt para informar valor (SEM NF)

### 5.3 Badge no Ícone
- Admin: ordens em "Contratar" sem fornecedor
- Vendedor: ordens DELE sem fornecedor
- Atualiza a cada 15 segundos

### 5.4 Links de WA
- Formato novo: `?token=UUID`
- Fallback ordens antigas: `?id=LC20266xxx`

---

## 6. Tracking do Cliente (tracking.html)

- Página pública — acesso via link de WhatsApp
- Status visual (Pedido → Entrega → No local → Pagamento)
- QR Code PIX dinâmico (txid = GRP + número da OS)
- Agrupa todas as ordens pendentes do mesmo celular
- Branding personalizado por vendedor

---

## 7. Regras de Negócio

### 7.1 Lucro Líquido
```
LL = Receita - Custo - Taxa Adm (R$10) - (Receita × taxa_nf/100)
```
Vendedor informa valor SEM NF. Sistema calcula acréscimo automaticamente.

### 7.2 Arquivamento
Ordens `concluido` entram no fechamento APENAS se `pago=true` E `cancel_motivo` vazio.

### 7.3 Tracking Token
Ao duplicar uma ordem → sempre gera novo `tracking_token`. Nunca herda da original.

### 7.4 Cobrança
Entra na fila de cobrança quando: `pago=false` + não cobrada hoje + (col em: entrega/pagar/faltapg/baixar OU 3+ dias em aberto).

### 7.5 Taxa Administrativa
R$10 por ordem marcada no fechamento (de TODOS os vendedores). Configurável em Configurações.

---

## 8. Configurações

### 8.1 Variáveis

| Variável | Valor |
|---|---|
| SUPABASE_URL | https://ejfuqijtiberxsnvxdwm.supabase.co |
| SUPABASE_ANON_KEY | eyJhbGciOiJIUzI1NiIs... (hardcoded nos HTML) |
| ONESIGNAL_API_KEY | Supabase Secrets |
| ONESIGNAL_APP_ID | c2dbdd20-6f19-433f-8106-f45d3e37714d |

### 8.2 LocalStorage (Mobile)
- `csm_session` — token JWT
- `orc_lidos` — IDs de orçamentos visualizados
- `_groupStates` — estado dos grupos na fila

---

## 9. Edge Functions (Supabase)

### notificar-push
Envia push via OneSignal quando ordem entra em `contratar`.
- Endpoint: `POST .../functions/v1/notificar-push`
- Payload: `{ crm_id, logradouro, nome }`

---

## 10. Guia do Desenvolvedor

### 10.1 Arquivos

| Arquivo | Descrição | Linhas |
|---|---|---|
| index.html | CRM Desktop completo | ~12.500 |
| mobile2.html | App Mobile PWA | ~5.600 |
| tracking.html | Rastreamento público | ~500 |
| cadastro.html | Cadastro de usuários | ~200 |
| sw.js | Service Worker | ~100 |

### 10.2 Adicionar Novo Vendedor
1. Criar usuário no Supabase Auth
2. Inserir em `perfis` com `nivel = 'operador'`
3. Adicionar nome em `_modeloComissao()` no index.html
4. Adicionar bloco de cálculo em `_calcFechamento()` se modelo diferente

### 10.3 Padrões de Código
- Funções internas: prefixo `_` (ex: `_calcFechamento`)
- IDs HTML: `secao_campo_uid` (ex: `fech_total_abc123`)
- `api()` — wrapper para todas as chamadas Supabase REST
- `fmt(valor)` — formata como moeda BR (2 casas decimais)
- `toast(msg, tipo)` — notificações temporárias
- `showConfirm({})` — modal de confirmação

---

## 11. Checklist de Funcionalidades

### Desktop
- ✅ Kanban com drag & drop
- ✅ Busca em tempo real
- ✅ Filtro por vendedor
- ✅ Dashboard com KPIs
- ✅ Card ordens clicável com relatório de status
- ✅ Comissões com cálculo em tempo real
- ✅ Botão desfazer fechamento
- ✅ Conciliação bancária (PIX, RC, GRP)
- ✅ Notas fiscais com regras de tributação
- ✅ Pagar fornecedor
- ✅ Cobrança automática via WA
- ✅ Histórico de ações
- ✅ Alertas de IA
- ✅ Relatórios
- ✅ Cadastro de fornecedores com regiões

### Mobile
- ✅ PWA instalável
- ✅ Badge no ícone em tempo real
- ✅ Fila de ações por grupo
- ✅ Vendedor vê grupo Contratar
- ✅ Alerta piscando para valor sem preencher
- ✅ Links WA com tracking_token correto
- ✅ Cobrança em lote
- ✅ Auto-refresh 15 segundos
- ✅ Notificações push OneSignal

### Tracking
- ✅ Status visual da OS
- ✅ QR Code PIX dinâmico
- ✅ Branding por vendedor
- ✅ Agrupa ordens do mesmo celular
- ✅ Compatível com link antigo e novo

---

*CaçambaSP — Documento Confidencial — Maio de 2026*
